#ifndef SORTS_H
#define SORTS_H

void select_sort(char* l,char* r);
void insert_sort(char* l,char* r);
void bubble_sort(char* l,char* r);
void quick_sort(char* l,char* r);

#endif
